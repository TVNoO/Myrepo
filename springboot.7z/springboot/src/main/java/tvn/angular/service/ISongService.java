package tvn.angular.service;

import tvn.angular.entity.Song;

public interface ISongService {
	
	Iterable<Song> findAll();

	Song findOne(int id);

    void save(Song song);

    void delete(int id);
}
