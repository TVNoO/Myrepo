package tvn.angular.repository;

import org.springframework.data.repository.CrudRepository;

import tvn.angular.entity.*;

public interface SongRepository extends CrudRepository<Song, Integer>{
	
}
