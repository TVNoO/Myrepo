//package tvn.com.util;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import tvn.com.entity.Server;
//import tvn.com.service.ServerService;
//
//public class DoTest {
//	@Autowired
//	private static ServerService serverS;
//	
//	public void print() {
//		List<Server> list = (List<Server>) serverS.findAll();
//		System.out.println(list);
//	}
//	
//}
