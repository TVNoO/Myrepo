angular.module('userManagement', []).controller('userController',
		function($scope, $http) {
			$scope.users = [];
			$scope.userForm = {
				id : -1,
				email : "",
				password : ""
			};

			// load the data from server
			_refreshUserData();

			// Created user
			$scope.submitUser = function() {

				var method = "";
				var url = "";
				if ($scope.userForm.id == -1) {
					// Id is absent in form data, it is create new
					// user operation
					method = "POST";
					url = '/app/user/';
				} else {
					// Id is present in form data, it is edit user
					// operation
					method = "PUT";
					url = '/app/user/' + $scope.userForm.id;
				}

				$http({
					method : method,
					url : url,
					data : angular.toJson($scope.userForm),
					headers : {
						'Content-Type' : 'application/json'
					}
				}).then(_success, _error);
			};

			// DELETE- delete user by Id
			$scope.deleteUser = function(user) {
				$http({
					method : 'DELETE',
					url : '/app/user/' + user.id
				}).then(_success, _error);
			};

			// edit with user id
			$scope.editUser = function(user) {

				$scope.userForm.email = user.email;
				$scope.userForm.password = user.password;
				$scope.userForm.id = user.id;
			};

			/* Private Methods */
			// HTTP GET- get all user collection
			function _refreshUserData() {
				$http({
					method : 'GET',
					url : 'http://localhost:8080/app/user/'
				}).then(function successCallback(response) {
					$scope.users = response.data;
				}, function errorCallback(response) {
					console.log(response.statusText);
				});
			}

			function _success(response) {
				_refreshUserData();
				_clearFormData()
			}

			function _error(response) {
				console.log(response.statusText);
			}

			// Clear the form
			function _clearFormData() {
				$scope.userForm.id = -1;
				$scope.userForm.email = "";
				$scope.userForm.password = "";

			}
			;

		});
