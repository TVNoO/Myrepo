package tvn.angular.service;

import tvn.angular.entity.User;

public interface IUserService {
	
	Iterable<User> findAll();

    User findOne(int id);

    void save(User contact);

    void delete(int id);
    
    User findByEmailAndPassword(String email, String password);
    
    User findByEmail(String email);
}
