package tvn.angular.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tvn.angular.entity.Song;
import tvn.angular.repository.SongRepository;

@Service
public class SongService implements ISongService {
	
	@Autowired
	SongRepository songRepository;

	@Override
	public Iterable<Song> findAll() {
		// TODO Auto-generated method stub
		return songRepository.findAll();
	}

	@Override
	public Song findOne(int id) {
		// TODO Auto-generated method stub
		return songRepository.findOne(id);
	}

	@Override
	public void save(Song song) {
		// TODO Auto-generated method stub
		songRepository.save(song);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		songRepository.delete(id);
	}

	
	
}
