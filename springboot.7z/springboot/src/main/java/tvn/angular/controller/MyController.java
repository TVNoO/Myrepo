package tvn.angular.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import tvn.angular.service.UserService;

@Controller
@RequestMapping("/app")
public class MyController {
	@Autowired
	UserService userService;
	
	@GetMapping("manageuser")
	public String goManagerUser(Model model) {
		model.addAttribute("list", userService.findAll());
		return "managerUser";
	}
	
	@GetMapping("cal")
	public String goCal() {
		return "cal";
	}
}
