package tvn.angular.repository;


import org.springframework.data.repository.CrudRepository;

import tvn.angular.entity.*;

public interface UserRepository extends CrudRepository<User, Integer> {
	public User findByEmailAndPassword(String email, String password);
	public User findByEmail(String email);
}
